import './App.css';
import { useState} from "react";

function App() {
  const [pokemon, setPokemon] = useState([]);

  const onClickHandler = () => {
    console.log("Fetching all Pokemon...");
    fetch('https://pokeapi.co/api/v2/pokemon?limit=807')
    .then(res => res.json())
    .then(res => setPokemon(res.results))
    .catch(err => console.log(err))
    console.log("changing Pokemon...");
  }

  return (
    <div className="App">
      <button onClick={onClickHandler}>Fetch Pokemon!</button>
      <ul>
        {
          pokemon.map((item, key) =>{
            return <li key={key}>{item.name}</li>
          })
        }
      </ul>
    </div>
  );
}

export default App;
