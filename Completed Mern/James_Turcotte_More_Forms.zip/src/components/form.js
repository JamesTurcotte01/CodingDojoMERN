import React, {useState} from  'react';
        
const UserForm = (props) => {
    const {inputs, setInputs} = props;
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setconfirmPassword] = useState("");
    const [firstNameError, setfirstNameError] = useState("");
    const [lastNameError, setlastNameError] = useState("");
    const [emailError, setemailError] = useState("");
    const [passwordError, setpasswordError] = useState("");
    const [confirmPasswordError, setconfirmPasswordError] = useState("");

    const createUser = (e) => {
        e.preventDefault();
        const user = {firstName, lastName, email, password, confirmPassword};
        console.log("Welcome", user)
    }

    const fNameError = (e) => {
        setfirstName(e.target.value)
        if(e.target.value.length < 3) {
            setfirstNameError('First Name needs three letters!')
        }else{
            setfirstNameError('')
        }
    }

    const lNameError = (e) => {
        setlastName(e.target.value)
        if(e.target.value.length < 3) {
            setlastNameError('Last Name needs three letters!')
        }else{
            setlastNameError('')
        }
    }

    const EmailError = (e) => {
        setEmail(e.target.value)
        if(e.target.value.length < 5) {
            setemailError('You need three letters!')
        }else{
            setemailError('')
        }
    }

    const PasswordError = (e) => {
        setPassword(e.target.value)
        if(e.target.value.length < 8) {
            setpasswordError('You need 8 letters!')
        }else{
            setpasswordError('')
        }
    }

    const ConfirmPasswordError = (e) => {
        setconfirmPassword(e.target.value)
        if(e.target.value !== password) {
            setconfirmPasswordError('passwords must match!')
        }else{
            setconfirmPasswordError('')
        }
    }

    const onChange = (e) => { setInputs({
                ...inputs,
                [e.target.name]: e.target.value
    });
    };
    
    return(
    <div>
        <form>
            <label>First Name:</label>
            <input type="text" onChange={fNameError} name="firstName"/>
            <label>Last Name:</label>
            <input type="text" onChange={lNameError} name="lastName"/>
            <label>Email:</label>
            <input type="text" onChange={EmailError} name="email"/>
            <label>Password:</label>
            <input type="text" onChange={PasswordError} name="password"/>
            <label>Confirm Password:</label>
            <input type="text" onChange={ConfirmPasswordError} name="confirm"/>
        </form>
            <div>
                <h2>{firstName}</h2>
                <h2>{firstNameError}</h2>
            </div>
            <div>
                <h2>{lastName}</h2>
                <h2>{lastNameError}</h2>
            </div>
            <div>
                <h2>{email}</h2>
                <h2>{emailError}</h2>
            </div>
            <div>
                <h2>{password}</h2>
                <h2>{passwordError}</h2>
            </div>
            <div>
                <h2>{confirmPassword}</h2>
                <h2>{confirmPasswordError}</h2>
            </div>
        </div>
    );
};

    
export default UserForm;