import React, { useState } from  'react';
import './App.css';
import UserForm from './components/form.js';


function App() {
  const [state, setState] = useState ({
    firstName: "",
    firstNameError: "",
    lastName: "",
    lastNameError: "",
    email: "",
    emailError: "",
    password: "",
    passwordError: "",
    confirm: "",
    confirmPasswordError: "",
  });
  return (
    <div className="App">
      <UserForm inputs={state} setInputs={setState}/>
    </div>
  );
}
export default App;
