import React, {useState} from  'react';

const tasks = [
    'run',
    'walk the dog',
    'become president',
    'invent an invention that invents inventions',
];

export default function UserForm() {
    const [selectedTask, setSelectedTasks] = useState(tasks[0]);
    const [isCompleted, setIsCompleted] = useState(false);

    function handleSubmit(event) {
        event.preventDefault();
        console.log(selectedTask + ' is' + (isCompleted ? '' : ' not') + ' done!');
    }

    return (
        <form onSubmit={handleSubmit}>
            <select value={selectedTask} onChange={e => setSelectedTasks(e.target.value)}>
                {tasks.map((task, idx) => (
                    <option key={idx} value={task}>{task}</option>
                ))}
            </select>
            <label>
                <input type="checkbox" checked={isCompleted} onChange={e => setIsCompleted(e.target.checked)}/> Is it complete?
            </label>
            <button>Task is Complete!</button>
        </form>
    )
};


