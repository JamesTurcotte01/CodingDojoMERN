import './App.css';
import React, { useState } from  'react';
import UserForm from './components/list.js';

function App() {
  const [state, setState] = useState ({
    selectedTask: "",
    isCompleted: "",
  });
  return (
    <div className="App">
      <UserForm inputs={state} setInputs={setState}/>
    </div>
  );
}

export default App;
