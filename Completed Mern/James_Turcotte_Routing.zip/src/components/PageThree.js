import React from 'react';

const Colors = props => {
    return (
    <div style="background-color:{props.color}">
        <h1>The word is: {props.word}</h1>
    </div>
    )
}
export default Colors;