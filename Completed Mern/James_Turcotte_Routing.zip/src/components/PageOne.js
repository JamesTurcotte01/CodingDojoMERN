import React from 'react';

const Numbers = props => {
    return (
        isNaN(props.num) ? <p>sorry, please use a number</p>:<h1>The Number is: {props.num}</h1>

    )
}
export default Numbers;