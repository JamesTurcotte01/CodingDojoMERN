import React from 'react';

const Words = props => {
    return (
        <h1>The word is: {props.word}</h1>

    )
}
export default Words;