import './App.css';

import {Router} from '@reach/router';
import Numbers from './components/PageOne.js';
import Welcome from './components/Welcome.js';
import Words from './components/PageTwo.js';
import Colors from './components/PageThree.js';

function App() {
  return (
    <div className="App">
      <Router>
        <Welcome path="/"/>
        <Numbers path="/:num"/>
        <Words path="/words/:word"/>
        <Colors path="/:word/:color"/>
      </Router>
    </div>
  );
}
export default App;
