// //BUBLE SORT//

// function bubble_Sort(a)
// {
//     var change;
//     var n = a.length-1;
//     var x=a;
//     do {
//         change = false;
//         for (var i=0; i < n; i++)
//         {
//             if (x[i] < x[i+1])
//             {
//                 var temp = x[i];
//                 x[i] = x[i+1];
//                 x[i+1] = temp;
//                 change = true;
//             }
//         }
//         n--;
//     } while (change);
// return x; 
// }

// console.log(bubble_Sort([12, 345, 4, 546, 122, 84, 98, 64, 9, 1, 3223, 455, 23, 234, 213]));

// //SELECTION SORT//

// function Selection_Sort(arr, compare_Function) {

//         function compare(a, b) {
//         return a - b;
//         } 
//         var min = 0;
//         var index = 0;
//         var temp = 0;
    
//     //{Function} compare_Function Compare function
//         compare_Function = compare_Function || compare;
    
//         for (var i = 0; i < arr.length; i += 1) {
//         index = i;
//         min = arr[i];
    
//         for (var j = i + 1; j < arr.length; j += 1) {
//             if (compare_Function(min, arr[j]) > 0) {
//             min = arr[j];
//             index = j;
//             }
//         }
    
//         temp = arr[i];
//         arr[i] = min;
//         arr[index] = temp;
//         }
    
//         //return sorted arr
//         return arr;
//     }
    
// console.log(Selection_Sort([3, 0, 2, 5, -1, 4, 1], function(a, b) { return a - b; })); 
// console.log(Selection_Sort([3, 0, 2, 5, -1, 4, 1], function(a, b) { return b - a; }));

// //looping through the array from 0 to arr.length,
// //shift a value in the array back to the place it belongs
// //the value to shift should increment with each loop iteration
// //follow this example for each step, with the current value in ()
// //step one: [(6),4,5,2,8,14,1,3] -> [(6),4,5,2,8,14,1,3]
// //step two: [6,(4),5,2,8,14,1,3] -> [(4),6,5,2,8,14,1,3]
// //step three: [4,6,(5),2,8,14,1,3] -> [4,(5),6,2,8,14,1,3]
// //step four: [4,5,6,(2),8,14,1,3] -> [(2),4,5,6,8,14,1,3]
// //step five: [2,4,5,6,(8),14,1,3] -> [2,4,5,6,(8),14,1,3]
// //and so on...

// const insertionSort = (arr) => {
//     for (let i=1; i<arr.length; i++){
//         while (arr[i] < arr[i-1]){
//             [arr[i], arr[i-1]] = [arr[i-1], arr[i]];
//             i--;
//         }
//     }
//     return arr;
// }
// console.log(insertionSort([6,4,5,2,8,14,1,3]));

// //another way

// let insertionSort = (arr) => {
//     let length=arr.length;
//     for(let i=1;i<length;i++){
//         let key=arr[i];
//         let j=i-1
//         while(j>=0 && arr[j]>key){
//             arr[j+1]=arr[j];
//             j=j-1;
//         }
//         arr[j+1]=key;
//     }
//     return arr;
// }

// console.log(insertionSort([6,4,5,2,8,14,1,3]));

// //combine two pre-sorted arrays into one sorted array
// //return the newly combined array
// //bonus challenge: combine in place into leftArr instead of a new array
// const combine = (leftArr, rightArr) => {
//     return;
// }

// //should return [0,1,2,3,4,6,7,9,11]
// // console.log(combine([1,2,7,9],[0,3,4,6,11]));

// //should return [0,1]
// // console.log(combine([1],[0]));


// //use recursion to break up the array into halves and combine two sorted halves.
// //each half should be split in half, and so on, until you get single item arrays
// //use combine() to combine the arrays
// const mergeSort = (arr) => {
//     if (arr.length == 1){
//         return combine(arr);
//         // return arr;
//     }
//     else{
//         var leftHalf = arr.slice(0, Math.floor(arr.length/2))
//         var rightHalf = arr.slice(Math.floor(arr.length/2))
//         console.log("Left half = " + leftHalf);
//         console.log("Right half = " + rightHalf);
//         if (leftHalf.length > 1){
//             mergeSort(leftHalf);
//         }
//         if (rightHalf.length > 1){
//             mergeSort(rightHalf);
//         }
//     }
//     return arr;
// }
// //should return [1,2,3,4,5,6,8,14]
// // console.log(mergeSort([5,4,2,6,8,14,1,3]));

// const combine = (leftArr, rightArr) => {
//     let mergedArray = [];
//     let leftLength = leftArr.length;
//     let rightLength = rightArr.length;
//     for (let i=0; i < (leftLength + rightLength); i++){
//         if (leftArr.length == 0){
//             mergedArray.push(...rightArr);
//             return mergedArray;
//         }
//         else if (rightArr.length == 0){
//             mergedArray.push(...leftArr);
//             return mergedArray;
//         }
//         else if (leftArr[0] > rightArr[0]){
//             mergedArray.push(rightArr[0]);
//             rightArr.splice(0, 1);
//         }
//         else {
//             mergedArray.push(leftArr[0]);
//             leftArr.splice(0, 1);
//         }
//     }
//     return mergedArray;

// //

// const mergeSort = (arr) => {
//     if (arr.length == 1){
//         return arr;
//     }
//     else{
//         var leftHalf = arr.slice(0, Math.floor(arr.length/2))
//         var rightHalf = arr.slice(Math.floor(arr.length/2))
//         console.log("Left half = " + leftHalf);
//         console.log("Right half = " + rightHalf);
//         return combine(mergeSort(leftHalf), mergeSort(rightHalf));
//     }
// }

// //

// const combine = (leftArr, rightArr) => {
//     let arr = []
//     while (leftArr.length && rightArr.length) {

//         if (leftArr[0] < rightArr[0]) {
//             arr.push(leftArr.shift())  
//         } else {
//             arr.push(rightArr.shift()) 
//         }
//     }

//     return [ ...arr, ...leftArr, ...rightArr ]
// }

// console.log(combine([1,2,7,9],[0,3,4,6,11]));
// console.log(combine([1],[0]));

// //

// const mergeSort = (arr) => {
//     const half = arr.length / 2

//     if(arr.length < 2){
//     return arr 
//     }
//     const left = arr.splice(0, half)
//     return combine(mergeSort(left),mergeSort(arr))
// }

// console.log(mergeSort([5,4,2,6,8,14,1,3]));

// //


// //partition the array around the value at arr[0]
// //without creating a new array
// //values left of the original pivot should be less than the pivot
// //values right of the pivot should be >= the pivot value
// //note: each side of the partitioned value does not
// //have to be sorted.
// //return the partitioned array
// //[5,4,9,2,5,3] -> [4,2,3,5,9,5]
// const partition = (arr) => {

// }

// //should return [4,2,3,5,9,5]
// console.log(partition([5,4,9,2,5,3]));

// const partition = (arr) => {
//     var part = arr[0];
//     for (let i=1; i<arr.length; i++){
//         if (arr[i] < part) {
//             let temp = arr[i];
//             arr.splice(i, 1);
//             arr.splice(0, 0, temp);
//         }
//     }
//     return arr;
// }

// //given a string of words(with spaces),
// //return an array of words
// //"Did I shine my shoes today?" ->
// //returns ["Did","I","shine","my","shoes","today?"]
// //"two             words" -> ["two","words"]
// const stringToWordArray = (str) => {
// //write a function that, given a string of words(with spaces),
// //returns a new string with words in reverse sequence.
// //"This is a test" -> "test a is This"
// const reverseWordOrder = (str) => {}

//given a string of words(with spaces),
//return an array of words
//"Did I shine my shoes today?" ->
//returns ["Did","I","shine","my","shoes","today?"]
//"two             words" -> ["two","words"]
// const stringToWordArray = (words) => {
//         return words.trim().split(" ");
// };
// console.log(stringToWordArray("two men enter one man leaves!"));

// //write a function that, given a string of words(with spaces),
// //returns a new string with words in reverse sequence.
// //"This is a test" -> "test a is This"
// const reverseWordOrder = (str) => {

// }

//Intersect Sorted Arrays
//Given two sorted arrays, return a new array containing all the numbers they have in common

//Ex: given [2,4,7,9,10] and [2,3,5,7,9,10], return [2,7,9,10]
//Ex: given [1,1,4,5,8] and [1,1,1,5,6,8] return [1,1,5,8]
//Ex: given [1,3,5,7,9] and [2,4,6,8,10] return []

// const intersect = (arrLeft, arrRight) => {
//         var results = [];
//         if( arrLeft.length == 0 || arrRight.length == 0){
//                 return results;
//         }
//         for(let i = 0; i<arrLeft.length; i++){
//                 for( let j=0; j<arrRight.length; j++){
//                         if (arrLeft[i] == arrRight[j]){

//                         results.push(arrLeft[i]);
//                         }
//                         i++;
//                         j--;
                
//                         else if (arrLeft[i] < arrRight[j]){
//                         i++;
//                 } 
//                         else {
//                         j++;
//                 }}
//         }
//         return(results);
// }

// console.log(intersect([2,4,7,9,10],[2,3,5,7,9,10]));
// console.log(intersect([1,1,4,5,8],[1,1,1,5,6,8]));
// console.log(intersect([1,3,5,7,9],[2,4,6,8,10]));
// console.log(intersect([],[1,2,3,4,5]));

// const intersect = (arrLeft, arrRight) => {
//         let left = 0;
//         let right = 0;
//         var results = [];
//         while(left !== arrLeft.length && right !== arrRight.length){
//                 if (arrLeft[left] == arrRight[right]){
//                         results.push(arrRight[right]);
//                         left++;
//                         right++;
//                 }
//                 else if(arrLeft[left] > arrRight[right]){
//                         right++;
//                 }
//                 else left++;
//         }
//         return results;
// }
// // console.log(intersect([2,4,7,9,10],[2,3,5,7,9,10]));
// // console.log(intersect([1,1,4,5,8],[1,1,1,5,6,8]));
// // console.log(intersect([1,3,5,7,9],[2,4,6,8,10]));
// // console.log(intersect([],[1,2,3,4,5]));
// console.log(intersect([-9, 1, 3, 4, 4, 4, 4, 4, 4, 5, 7], [-5, 0, 1, 1, 1, 1, 1, 2, 4, 4, 6, 7]));

//return a new unsorted union multiset of two arrays
//essentially same as yesterday but your input is unsorted
//don't just sort the arrays, then do a union!

//[2,7,2,1,2], [6,7,2,7,6,2] returns [7,2,7,2,2,1,6,6]
//(or a different combination of the same numbers, since it's unsorted)
// const union = (leftArr, rightArr) => {

//         if ((leftArr == null) || (rightArr==null)) 
//                 return void 0;
        
//         var obj = {};
//         for (var i = leftArr.length-1; i >= 0; -- i)
//                 obj[leftArr[i]] = leftArr[i];
//         for (var i = rightArr.length-1; i >= 0; -- i)
//                 obj[rightArr[i]] = rightArr[i];
//         var res = [];

//         for (var n in obj)
//         {
        
//                 if (obj != (n)) 
//                 res.push(obj[n]);
//         }

//         return res;
// }
// console.log(union([1, 2, 3], [100, 2, 1, 10]));
// console.log(union([2,7,2,1,2], [6,7,2,7,6,2]));

//create a function that accepts a string representing an int
//in binary notation, and returns the int
//you do not need to use parseInt
//should return integer >= 0

//given "1010101", return 85
//given "100011", return 35

// const binToDec = (str) => {
// }

// console.log(binToDec("1010101"));
// console.log(binToDec("100011"));