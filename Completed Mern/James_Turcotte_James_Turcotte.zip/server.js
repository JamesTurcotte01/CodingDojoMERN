const express = require('express');
const app=express();
const port=8000;
const faker = require('faker');

app.use(express.json());
app.use(express.urlencoded({extended:true}))

app.get("/api/user/new", (req, res) => {
    let this_user = new user(req.params.id);
    res.json({user: this_user})
})

app.get("/api/companies/new", (req, res) => {
    let this_company = new company(req.params.id);
    res.json({company: this_company})
})

app.get("/api/user/company", (req, res) => {
    let this_company = new company(req.params.id);
    let this_user = new user(req.params.id);
    res.json({user: this_user, company: this_company})
})

class user {
    constructor() {
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
    }
}

class company {
    constructor() {
        this.name = faker.company.companyName();
        this.address = faker.address.streetAddress();
        this.city = faker.address.cityPrefix();
        this.state = faker.address.state();
        this.zipCode = faker.address.zipCode();
        this.country = faker.address.country();
    }
}
console.log(new user());
console.log(new company());

app.listen(port, () => console.log("running..."));