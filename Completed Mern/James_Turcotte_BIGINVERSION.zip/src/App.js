import './App.css';
import People from './components/PersonCard.js';

function App() {
  return (
    <div className="App">
      <People first = "Jane" last = "Doe" age = {45} color = "Black"/>
      <People first = "John" last = "Smith" age = {88} color = "Brown"/>
      <People first = "Millard" last = "Fillmore" age = {50} color = "Brown"/>
      <People first = "Maria" last = "Smith" age = {62} color = "Brown"/>
    </div>
  );
}

export default App;
