import React from 'react';

const People = props => {
            return( 
                <div className="PersonCard">
                    <h1>{props.last}, {props.first}</h1>
                    <h3>Age: {props.age}</h3>
                    <h3> Haircolor: {props.color}</h3>
                </div>
            );
    }
export default People;