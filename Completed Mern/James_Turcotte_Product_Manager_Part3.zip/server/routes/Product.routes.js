const ProductController = require("../controllers/Product.controller");

module.exports = app => {
  app.get("/api/Product/", ProductController.findAllProduct);
  app.get("/api/Product/:id", ProductController.findOneSingleProduct);
  app.put("/api/Product/update/:id", ProductController.updateExistingProduct);
  app.post("/api/Product/new", ProductController.createNewProduct);
  app.delete("/api/Product/delete/:id", ProductController.deleteAnExistingProduct);
};