// ninja class parent
class ninja {
    constructor(name) {
        this.name = name;
        this.health = 10;
        this.speed = 3;
        this.strength = 3;
    }
    sayName() {
        this.name = this.name;
        console.log(`Ninjas name: ${ this.name }`);
    }
    showStats() {
        this.miles += 10;
        console.log(`you now have ${this.health} health.`);
        console.log(`you now have ${this.speed} speed.`);
        console.log(`you now have ${this.strength} strength.`);
    }
    drinkSake() {
        this.health += 10;
        console.log(`You drink some warm Sake and your health goes up! your health is now: ${this.health}`);
    }   
}
const ninja1 = new ninja("Mark Zuccerberg");

// child 
class sensei extends ninja {
    constructor(name) {
        super(name, 200, 10, 10);
        this.name = name;
        this.health = 200;
        this.speed = 10;
        this.strength = 10;
    }
    speakWisdom() {
        const wiseoldman = super.drinkSake();
        console.log("An apple a day will keep anyone away if you throw it hard enough.")
    }
}
const superSensei = new sensei("Master Splinter");
superSensei.sayName();
superSensei.showStats();
superSensei.speakWisdom();