// ninja class parent
class ninja {
    constructor(name, health) {
        this.name = name;
        this.health = health;
        this.speed = 3;
        this.strength = 3;
    }
    sayName() {
        this.name = name;
        console.log(`Ninjas name: ${ this.constructor.name }`);
    }
    sayStats() {
        this.miles += 10;
        console.log(`you now have ${this.health} health.`);
        console.log(`you now have ${this.speed} speed.`);
        console.log(`you now have ${this.strength} strength.`);
    }
    drinkSake() {
        this.health += 10;
        console.log(`You drink some warm Sake and your health goes up! your health is now: ${this.health}`);
    }
}
