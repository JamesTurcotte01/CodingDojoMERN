import React, { Component } from 'react';
    
    
class People extends Component {
    constructor(props){
        super(props);
        this.state = 
            {age: this.props.age};
        }
    
    render() {
    const onClick= () => this.setState({age: this.state.age + 1})
            return( 
                <div className="PersonCard">
                    <h1>{this.props.last}, {this.props.first}</h1>
                    <h3>Age: {this.state.age}</h3>
                    <h3>Haircolor: {this.props.color}</h3>
                    <button onClick ={onClick}>Birthday Button</button>
                </div>
            );
    }
}
export default People;