Microsoft Windows [Version 10.0.19042.867]
(c) 2020 Microsoft Corporation. All rights reserved.

C:\Users\James>cd c:/"Program Files"/MongoDB/Server/<version_number>/bin/
The system cannot find the file specified.

C:\Users\James> cd c:/"Program Files"/MongoDB/Server/<version_number>/bin
The system cannot find the file specified.

C:\Users\James> cd c:/"Program Files"/MongoDB/Server/<4.4.4>/bin
The system cannot find the file specified.

C:\Users\James>mongo.exe
'mongo.exe' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\James>https://fastdl.mongodb.org/windows/mongodb-windows-x86_64-4.4.4-signed.msi
'https:' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\James> cd c:/"Program Files"/MongoDB/Server/<version_number>/bin
The system cannot find the file specified.

C:\Users\James> cd c:/"Program Files"/MongoDB/Server/4.4.4/bin
The system cannot find the path specified.

C:\Users\James>cd program files
The system cannot find the path specified.

C:\Users\James>C:\Program Files\MongoDB\Server\4.4\bin
'C:\Program' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\James>cd C:\Program Files\MongoDB\Server\4.4\bin

C:\Program Files\MongoDB\Server\4.4\bin>mongo.exe
MongoDB shell version v4.4.4
connecting to: mongodb://127.0.0.1:27017/?compressors=disabled&gssapiServiceName=mongodb
Implicit session: session { "id" : UUID("4d6f77b8-804f-4331-b69d-487aef33231a") }
MongoDB server version: 4.4.4
Welcome to the MongoDB shell.
For interactive help, type "help".
For more comprehensive documentation, see
        https://docs.mongodb.com/
Questions? Try the MongoDB Developer Community Forums
        https://community.mongodb.com
---
The server generated these startup warnings when booting:
        2021-03-19T13:07:49.622-04:00: Access control is not enabled for the database. Read and write access to data and configuration is unrestricted
---
---
        Enable MongoDB's free cloud-based monitoring service, which will then receive and display
        metrics about your deployment (disk utilization, CPU, operation statistics, etc).

        The monitoring data will be available on a MongoDB website with a unique URL accessible to you
        and anyone you share the URL with. MongoDB may use this information to make product
        improvements and to suggest MongoDB products and deployment options to you.

        To enable free monitoring, run the following command: db.enableFreeMonitoring()
        To permanently disable this reminder, run the following command: db.disableFreeMonitoring()
---
> show dbs
admin   0.000GB
config  0.000GB
local   0.000GB
> db
test
> show dbs
admin   0.000GB
config  0.000GB
local   0.000GB
> use my_first_db
switched to db my_first_db
> db.createCollection("students")
{ "ok" : 1 }
> db.students.insert({name:"james", Home_State:"Massachusetts", Lucky_number:4, birthday:{month:6, day:5, year:199}})
WriteResult({ "nInserted" : 1 })
> db.students.insert({name:"terry", Home_State:"ohio", Lucky_number:1, birthday:{month:12, day:9, year:1999}})
WriteResult({ "nInserted" : 1 })
> db.students.insert({name:"jerry", Home_State:"maine", Lucky_number:2, birthday:{month:02, day:7, year:1990}})
WriteResult({ "nInserted" : 1 })
> db.students.insert({name:"merry", Home_State:"colorado", Lucky_number:2000, birthday:{month:01, day:17, year:1993}})
WriteResult({ "nInserted" : 1 })
> db.students.insert({name:"kerry", Home_State:"maryland", Lucky_number:10, birthday:{month:01, day:27, year:1996}})
WriteResult({ "nInserted" : 1 })
> db.students.find({})
{ "_id" : ObjectId("6054ee5b6f13ba6578458b38"), "name" : "james", "Home_State" : "Massachusetts", "Lucky_number" : 4, "birthday" : { "month" : 6, "day" : 5, "year" : 199 } }
{ "_id" : ObjectId("6054eea66f13ba6578458b39"), "name" : "terry", "Home_State" : "ohio", "Lucky_number" : 1, "birthday" : { "month" : 12, "day" : 9, "year" : 1999 } }
{ "_id" : ObjectId("6054eef66f13ba6578458b3a"), "name" : "jerry", "Home_State" : "maine", "Lucky_number" : 2, "birthday" : { "month" : 2, "day" : 7, "year" : 1990 } }
{ "_id" : ObjectId("6054ef3a6f13ba6578458b3b"), "name" : "merry", "Home_State" : "colorado", "Lucky_number" : 2000, "birthday" : { "month" : 1, "day" : 17, "year" : 1993 } }
{ "_id" : ObjectId("6054ef726f13ba6578458b3c"), "name" : "kerry", "Home_State" : "maryland", "Lucky_number" : 10, "birthday" : { "month" : 1, "day" : 27, "year" : 1996 } }
> db.students.find({Lucky_number: {$gt: 3}})
{ "_id" : ObjectId("6054ee5b6f13ba6578458b38"), "name" : "james", "Home_State" : "Massachusetts", "Lucky_number" : 4, "birthday" : { "month" : 6, "day" : 5, "year" : 199 } }
{ "_id" : ObjectId("6054ef3a6f13ba6578458b3b"), "name" : "merry", "Home_State" : "colorado", "Lucky_number" : 2000, "birthday" : { "month" : 1, "day" : 17, "year" : 1993 } }
{ "_id" : ObjectId("6054ef726f13ba6578458b3c"), "name" : "kerry", "Home_State" : "maryland", "Lucky_number" : 10, "birthday" : { "month" : 1, "day" : 27, "year" : 1996 } }
> db.student.find({Lucky_number: {$lte: 10}})
> db.students.find({Lucky_number: {$lte: 10}})
{ "_id" : ObjectId("6054ee5b6f13ba6578458b38"), "name" : "james", "Home_State" : "Massachusetts", "Lucky_number" : 4, "birthday" : { "month" : 6, "day" : 5, "year" : 199 } }
{ "_id" : ObjectId("6054eea66f13ba6578458b39"), "name" : "terry", "Home_State" : "ohio", "Lucky_number" : 1, "birthday" : { "month" : 12, "day" : 9, "year" : 1999 } }
{ "_id" : ObjectId("6054eef66f13ba6578458b3a"), "name" : "jerry", "Home_State" : "maine", "Lucky_number" : 2, "birthday" : { "month" : 2, "day" : 7, "year" : 1990 } }
{ "_id" : ObjectId("6054ef726f13ba6578458b3c"), "name" : "kerry", "Home_State" : "maryland", "Lucky_number" : 10, "birthday" : { "month" : 1, "day" : 27, "year" : 1996 } }
> db.students.find({Lucky_number: {$gt: 3}}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        }
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        }
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        }
}
> db.students.find({Lucky_number: {$lte: 10}}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        }
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        }
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        }
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        }
}
> db.students.find({Lucky_number: {$lte: 9, $gte: 1}}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        }
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        }
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        }
}
> db.students.update({}, {$set: {interests: "Coding", "Brunch", "MongoDB"}})
uncaught exception: SyntaxError: missing : after property id :
@(shell):1:60
> db.students.update({name: "james"}, {$set: {interests: "Coding", "Brunch", "MongoDB"}})
uncaught exception: SyntaxError: missing : after property id :
@(shell):1:73
> db.students.updateMany({}, {$set: {interests: ["Coding", "Brunch", "MongoDB"]})
... db.students.find({})
...
...
> db.students.find({})
{ "_id" : ObjectId("6054ee5b6f13ba6578458b38"), "name" : "james", "Home_State" : "Massachusetts", "Lucky_number" : 4, "birthday" : { "month" : 6, "day" : 5, "year" : 199 } }
{ "_id" : ObjectId("6054eea66f13ba6578458b39"), "name" : "terry", "Home_State" : "ohio", "Lucky_number" : 1, "birthday" : { "month" : 12, "day" : 9, "year" : 1999 } }
{ "_id" : ObjectId("6054eef66f13ba6578458b3a"), "name" : "jerry", "Home_State" : "maine", "Lucky_number" : 2, "birthday" : { "month" : 2, "day" : 7, "year" : 1990 } }
{ "_id" : ObjectId("6054ef3a6f13ba6578458b3b"), "name" : "merry", "Home_State" : "colorado", "Lucky_number" : 2000, "birthday" : { "month" : 1, "day" : 17, "year" : 1993 } }
{ "_id" : ObjectId("6054ef726f13ba6578458b3c"), "name" : "kerry", "Home_State" : "maryland", "Lucky_number" : 10, "birthday" : { "month" : 1, "day" : 27, "year" : 1996 } }
> db.students.find({}).pretty
function() {
    this._prettyShell = true;
    return this;
}
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        }
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        }
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        }
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        }
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        }
}
> db.students.updateMany({}, {$set: {interests: ["coding", "brunch", "mongoDB"]}})
{ "acknowledged" : true, "matchedCount" : 5, "modifiedCount" : 5 }
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB"
        ]
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB"
        ]
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB"
        ]
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB"
        ]
}
> db.students.update({name: "james"}, {$set: {$push: {interests: "flying"}}})
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 0,
        "nModified" : 0,
        "writeError" : {
                "code" : 52,
                "errmsg" : "The dollar ($) prefixed field '$push' in '$push' is not valid for storage."
        }
})
> db.students.update({name: "james"}, {$push: {interests: "flying"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.update({name: "kerry"}, {$push: {interests: "sitting"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.update({name: "terry"}, {$push: {interests: "breathing"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.update({name: "merry"}, {$push: {interests: "blinking"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.update({name: "jerry"}, {$push: {interests: "day drinking"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "flying"
        ]
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ]
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "blinking"
        ]
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "sitting"
        ]
}
> db.students.update({name: "jerry"}, {$push: {interests: "taxes"}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "flying"
        ]
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking",
                "taxes"
        ]
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "blinking"
        ]
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "sitting"
        ]
}
> db.students.update({name: "jerry"}, {$remove: {interests: "taxes"}})
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 0,
        "nModified" : 0,
        "writeError" : {
                "code" : 9,
                "errmsg" : "Unknown modifier: $remove. Expected a valid update modifier or pipeline-style update specified as an array"
        }
})
> db.students.update({name: "jerry"}, {$: {interests: "taxes"}})
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 0,
        "nModified" : 0,
        "writeError" : {
                "code" : 9,
                "errmsg" : "Unknown modifier: $. Expected a valid update modifier or pipeline-style update specified as an array"
        }
})
> db.students.update({name: "jerry"}, {$pop: {interests: "taxes"}})
WriteResult({
        "nMatched" : 0,
        "nUpserted" : 0,
        "nModified" : 0,
        "writeError" : {
                "code" : 9,
                "errmsg" : "Expected a number in: interests: \"taxes\""
        }
})
> db.students.update({name: "jerry"}, {$pop: {interests: (1)}})
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054ee5b6f13ba6578458b38"),
        "name" : "james",
        "Home_State" : "Massachusetts",
        "Lucky_number" : 4,
        "birthday" : {
                "month" : 6,
                "day" : 5,
                "year" : 199
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "flying"
        ]
}
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ]
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "blinking"
        ]
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "sitting"
        ]
}
> db.students.remove({name: "james"})
WriteResult({ "nRemoved" : 1 })
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ]
}
{
        "_id" : ObjectId("6054ef3a6f13ba6578458b3b"),
        "name" : "merry",
        "Home_State" : "colorado",
        "Lucky_number" : 2000,
        "birthday" : {
                "month" : 1,
                "day" : 17,
                "year" : 1993
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "blinking"
        ]
}
{
        "_id" : ObjectId("6054ef726f13ba6578458b3c"),
        "name" : "kerry",
        "Home_State" : "maryland",
        "Lucky_number" : 10,
        "birthday" : {
                "month" : 1,
                "day" : 27,
                "year" : 1996
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "sitting"
        ]
}
> db.students.remove({Lucky_number: {$gt: 5}})
WriteResult({ "nRemoved" : 2 })
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ]
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ]
}
> db.students.updateMany({}, {$set: {number_of_belts: 0}})
{ "acknowledged" : true, "matchedCount" : 2, "modifiedCount" : 2 }
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ],
        "number_of_belts" : 0
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ],
        "number_of_belts" : 0
}
> db.student.updateMany({Home_State: "ohio"},{$inc:{number_belts: 0}})
{ "acknowledged" : true, "matchedCount" : 0, "modifiedCount" : 0 }
> db.student.updateMany({Home_State: "ohio"},{$inc:{number_belts: 1}})
{ "acknowledged" : true, "matchedCount" : 0, "modifiedCount" : 0 }
> db.student.updateMany({}, {$rename: {number_belts: "belts_earned"}})
{ "acknowledged" : true, "matchedCount" : 0, "modifiedCount" : 0 }
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ],
        "number_of_belts" : 0
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ],
        "number_of_belts" : 0
}
> db.students.updateMany({}, {$rename: {number_belts: "belts_earned"}})
{ "acknowledged" : true, "matchedCount" : 2, "modifiedCount" : 0 }
> db.students.updateMany({Home_State: "ohio"},{$inc:{number_belts: 1}})
{ "acknowledged" : true, "matchedCount" : 1, "modifiedCount" : 1 }
> db.students.find({}).pretty()
{
        "_id" : ObjectId("6054eea66f13ba6578458b39"),
        "name" : "terry",
        "Home_State" : "ohio",
        "Lucky_number" : 1,
        "birthday" : {
                "month" : 12,
                "day" : 9,
                "year" : 1999
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "breathing"
        ],
        "number_of_belts" : 0,
        "number_belts" : 1
}
{
        "_id" : ObjectId("6054eef66f13ba6578458b3a"),
        "name" : "jerry",
        "Home_State" : "maine",
        "Lucky_number" : 2,
        "birthday" : {
                "month" : 2,
                "day" : 7,
                "year" : 1990
        },
        "interests" : [
                "coding",
                "brunch",
                "mongoDB",
                "day drinking"
        ],
        "number_of_belts" : 0
}
> db.student.updateMany({}, {$rename: {number_belts: "belts_earned"}})
{ "acknowledged" : true, "matchedCount" : 0, "modifiedCount" : 0 }
> db.students.updateMany({}, {$rename: {number_belts: "belts_earned"}})
{ "acknowledged" : true, "matchedCount" : 2, "modifiedCount" : 1 }
></version_number>