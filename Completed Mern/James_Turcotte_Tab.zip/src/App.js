import './App.css';
import React, {useState} from  'react';

const App = props => {
  const [tabs, setTab] = useState([
    {content: "This is a sample text. isnt it a cool sample? hopefully when you click on tab 1 it will display"},
    {content: "This is another sample text. isnt it a little cooler here on tab 2? hopefully when you click on tab 2 youll see this!"},
    {content:"This is the best sample text. isnt it so great and better then tab 1 and tab 2? hopefully when you click on tab 3 it will display in all its glory!"},
  ])

  const tabOnClick = (e, index, content) => {
      setSelected(index)
      setContent(content)
  }
  const [selected, setSelected] = useState(0)
  const [content, setContent] = useState("")
  return (
    <div className="App">
      {tabs.map((tab, index) => {
        return (
          <button
            key = {index}
            onClick = {e => tabOnClick(e, index, tab.content)}> Tab {index+1}</button>
        )
      })}
      <p>{ content }</p>
    </div>
  );
}
export default App;
