import './App.css';
import React from "react";
import Fetchaction from './components/stuff.js';

function App() {
  return (
    <div className="App">
      <Fetchaction/>
    </div>
  );
}

export default App;
