import { useState} from "react";
import axios from 'axios';

const Fetchaction = props => {
    const [pokemon, setPokemon] = useState([]);

    const onClickHandler = () => {
        axios.get('https://pokeapi.co/api/v2/pokemon?limit=807')
        .then(res=>setPokemon(res.data.results))
        .catch(err => console.log(err))
        };

        return (
            <div>
                <button onClick={onClickHandler}>Fetch Pokemon!</button>
                <ul>
                {
                pokemon && pokemon.map((item, key) =>{
                return <li key={key}>{item.name}</li>
                })
            }
            </ul>
        </div>
    );
}
export default Fetchaction;