import './App.css';
import Box from './components/boxes.js';
import 'bootstrap/dist/css/bootstrap.css';
import {useState} from "react";

function App() {
  const [state, setState] = useState({color:''})
  return (
    <div className="App">
      <Box inputs= {state} setInputs = {setState}/>
    </div>
  );
}
export default App;
