import React, {useState} from  'react';

const Box = (props) => {
    const [selectedColor, setSelectedColor] = useState([])
    const [form, setForm] = useState("")

    const prevent= (e) => {
        e.preventDefault()
        console.log(form)
        setSelectedColor([...selectedColor, form])
        setForm("")
    }

    return(
        <div>
            <form onSubmit ={prevent}>
                <div className="mt-5 pt-5 d-flex justify-content-center">
                    <label for="colFormLabel" className="col-form-label-lg">Color</label>
                    <div className="col-sm-5">
                        <input class="form-control form-control-lg" type="text" onChange={(e) => setForm(e.target.value)}/>
                    </div>
                    <div className="mt-1">
                        <button class="btn btn-primary">Add</button>
                    </div>
                </div>
            </form>
                <ul>
                    {
                    selectedColor.map((coloringBox) => {
                        const inline = {
                            display: 'inline-block',
                            height: '100px',
                            width: '100px',
                            backgroundColor : coloringBox
                        }
                        return(
                            <p className= 'mx-5 my-5' style = {inline}>{coloringBox}</p>
                        )
                    } )
                    }
                </ul>
        </div>
    );
}
export default Box;