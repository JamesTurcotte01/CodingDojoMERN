const mongoose = require("mongoose");

const JokesSchema = new mongoose.Schema({
	setup: {
		type: String,
		required: [true,"All jokes need a setup"],
		minlength: [10, "need to be at least 10 characters"],
	},
	punchline: {
		type: String,
		required: [true,"All jokes need a punchline"],
		minlength: [10, "add more words or whatever"],
}});

const Jokes = mongoose.model("Jokes", JokesSchema);

module.exports = Jokes;