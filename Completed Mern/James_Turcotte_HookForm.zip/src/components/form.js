import React from  'react';
    
const UserForm = (props) => {
    const {inputs, setInputs} = props;
    
    const onChange = (e) => { setInputs({
        ...inputs,
        [e.target.name]: e.target.value
    });
    };

    return(
        <form>
            <label>First Name:</label>
            <input type="text" onChange={onChange} name="firstName"/>
            <label>Last Name:</label>
            <input type="text" onChange={onChange} name="lastName"/>
            <label>Email:</label>
            <input type="text" onChange={onChange} name="email"/>
            <label>Password:</label>
            <input type="text" onChange={onChange} name="password"/>
            <label>Confirm Password:</label>
            <input type="text" onChange={onChange} name="confirm"/>
        </form>
    );
};
    
export default UserForm;