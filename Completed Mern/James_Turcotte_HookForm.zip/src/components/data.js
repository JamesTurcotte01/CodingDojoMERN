import React from 'react';

const Results = props => {
    const {firstName, lastName, email, password, confirm} = props.data;
    return (
        <div>
            <h2>{firstName}</h2>
            <h2>{lastName}</h2>
            <h2>{email}</h2>
            <h2>{password}</h2>
            <h2>{confirm}</h2>
        </div>
    )
}
export default Results;