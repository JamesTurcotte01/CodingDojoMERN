import React, { useState } from  'react';
import './App.css';
import UserForm from './components/form.js';
import Results from './components/data.js';


function App() {
  const [state, setState] = useState ({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirm: "",
  });
  return (
    <div className="App">
      <UserForm inputs={state} setInputs={setState}/>
      <Results data={state}/>
    </div>
  );
}
export default App;
